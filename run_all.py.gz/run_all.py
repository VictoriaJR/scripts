import glob
import os
import sys

files = [fname for fname in glob.glob('*.tre')]

print files
print len(files)

for i in files:
#  name = i.split('.')[1]
  name = i.split('_')[0]
  print name 
  print '%s.fasta' % (name)
  os.system ('python remove_and_rename_taxa_color.py %s ff0000 /Data/nick/Data_Denis/psammosa_seq/fastas/%s.trimal %s_clean.fasta ff00ff' % (i,name, name))
